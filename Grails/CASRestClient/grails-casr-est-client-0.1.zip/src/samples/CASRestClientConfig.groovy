/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

CASRestClient {
    cas {
        server = "https://authtest.it.usf.edu"
        ticketsPath = "/v1/tickets"        
        username = "myusername"    
        password = "mypassword"            
        
    }
}